//
//  ContentView.swift
//  Here, we build the user interface structure
//
//  Created by Amos Gyamfi on 6.8.2020.
//

import SwiftUI

struct ContentView: View {
    
    
    var body: some View {
        ZStack {
            Image("bg")
                .ignoresSafeArea()
            
            HStack(spacing: 30) {
                CalendarView()
                WeatherView()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
