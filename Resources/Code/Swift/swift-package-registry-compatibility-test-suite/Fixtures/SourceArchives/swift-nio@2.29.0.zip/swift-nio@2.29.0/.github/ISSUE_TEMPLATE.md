### Expected behavior
_[what you expected to happen]_

### Actual behavior
_[what actually happened]_

### Steps to reproduce

1. ...
2. ...

### If possible, minimal yet complete reproducer code (or URL to code)

_[anything to help us reproducing the issue]_

### SwiftNIO version/commit hash

_[the SwiftNIO tag/commit hash]_

### Swift & OS version (output of `swift --version && uname -a`)
