#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double SwiftyUserDefaultsVersionNumber;
FOUNDATION_EXPORT const unsigned char SwiftyUserDefaultsVersionString[];
