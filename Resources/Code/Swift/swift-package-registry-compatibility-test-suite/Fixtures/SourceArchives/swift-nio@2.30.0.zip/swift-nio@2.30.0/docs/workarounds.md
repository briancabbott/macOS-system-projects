# Workarounds

The following list of PRs and commits were applied in order to work around bugs
or cases where the Swift compiler was unable to sufficiently optimize the code:

- https://github.com/apple/swift-nio/pull/1374
- https://github.com/apple/swift-nio-ssl/pull/176
- https://github.com/apple/swift-nio/pull/1325
- https://github.com/apple/swift-nio/pull/1299
- https://github.com/apple/swift-nio/pull/1252
- https://github.com/apple/swift-nio/pull/494
- https://github.com/apple/swift-nio/pull/420
- https://github.com/apple/swift-nio/commit/abc963cfe1e1d4856c41421c9d53ea778102e9e8
- https://github.com/apple/swift-nio/pull/1814
