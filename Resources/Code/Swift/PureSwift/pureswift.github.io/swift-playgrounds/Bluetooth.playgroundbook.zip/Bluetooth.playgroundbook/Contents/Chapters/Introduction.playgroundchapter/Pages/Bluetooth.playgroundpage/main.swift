//#-hidden-code
import UIKit
import PlaygroundSupport

let liveView = UIView()

PlaygroundPage.current.liveView = liveView
PlaygroundPage.current.needsIndefiniteExecution = true

enum PlaygroundColor {
    static let yellow = UIColor(red: 1, green: 237/255.0, blue: 117/255.0, alpha: 1)
    static let green = UIColor(red: 110/255.0, green: 240/255.0, blue: 167/255.0, alpha: 1)
    static let blue = UIColor(red: 66/255.0, green: 197/255.0, blue: 1, alpha: 1)
    static let orange = UIColor(red: 1, green: 159/255.0, blue: 70/255.0, alpha: 1)
}

enum PlaygroundLog {
    static var log: String {
        guard let assessmentStatus = PlaygroundPage.current.assessmentStatus else { return "" }

        switch assessmentStatus {
        case let .pass(message): return message ?? ""
        default: return ""
        }
    }

    static func print(_ message: Any, clearAfter seconds: Int = 0) {
        let newMessage = "◦ \(message)"
        let assessmentStatus = log.isEmpty ? newMessage : "\(log)\n\n\(newMessage)"
        PlaygroundPage.current.assessmentStatus = .pass(message: assessmentStatus)
        if (seconds > 0) { PlaygroundLog.clear(after: seconds) }
    }

    static func clear(after seconds: Int = 0) {
        guard seconds > 0 else {
            PlaygroundPage.current.assessmentStatus = nil; return
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(seconds)) {
            PlaygroundPage.current.assessmentStatus = nil
        }
    }
}

PlaygroundLog.clear()
liveView.backgroundColor = PlaygroundColor.blue
func print(_ message: String) {
    PlaygroundLog.print(message)
}
//#-end-hidden-code
import Bluetooth

let uuid = BluetoothUUID(rawValue: "60F14FE2-F972-11E5-B84F-23E070D5A8C7")!
let uuid16bit = BluetoothUUID(rawValue: "FEA9")!
let company = CompanyIdentifier.apple
let address = BluetoothAddress(rawValue: "00:1A:7D:DA:71:13")!
let beacon = AppleBeacon(
    uuid: UUID(uuidString: "CFDF18CF-92FB-4C60-B2CA-6F1487A6EBC6")!,
    major: 0,
    minor: 0,
    rssi: -10
)

print("The Bluetooth library provides value types based on the Bluetooth SIG specifications.")

print("UUID: \(uuid)")
print("Address: \(address)")
