/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The BrandXAccessorySetup AppDelegate.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
}

