# Filtering Network Traffic

Use the Network Extension framework to allow or deny network connections.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [714: Network Extensions for Modern macOS](https://developer.apple.com/videos/play/wwdc19/714/)

## Configure the Sample Code Project

This sample code project only runs on macOS.
