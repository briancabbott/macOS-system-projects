/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Defines the application's delegate class.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}
