# Classifying Images for Categorization and Search

Analyze and label images using a Vision classification request.

## Overview

- Note: For more information about this sample code project, see [WWDC 2019 Session 222: Understanding Images in Vision Framework](https://developer.apple.com/videos/play/wwdc19/222/).
