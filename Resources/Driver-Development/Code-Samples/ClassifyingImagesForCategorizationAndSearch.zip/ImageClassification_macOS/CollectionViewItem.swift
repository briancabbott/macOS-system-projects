/*
See LICENSE folder for this sample’s licensing information.

Abstract:
CollectionViewItem subclass.
*/

import Cocoa

class CollectionViewItem: NSCollectionViewItem {
}
