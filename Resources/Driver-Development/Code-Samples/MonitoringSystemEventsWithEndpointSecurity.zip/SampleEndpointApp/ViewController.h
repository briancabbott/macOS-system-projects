/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The app's main view controller, which presents a user interface for installing the extension.
*/
#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@end

