# Collecting Network Connection Metrics

Use reports to understand how DNS and protocol handshakes impact
connection establishment.

## Overview

- Note: This sample code project is associated with WWDC 2019 session [713: Advances in Networking, Part 2](https://developer.apple.com/videos/play/wwdc19/713/).
